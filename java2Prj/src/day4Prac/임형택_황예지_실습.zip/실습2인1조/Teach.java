package day4Prac.실습2인1조;

public interface Teach {
	
	String teach(String subject);
	
	void 국어수업듣기();
	void 영어수업듣기();
	void 수학수업듣기();
	
	
}
