package day4Prac.실습2인1조;

public class School {
	
	public String Teach(String subject) {
		return subject;
	}
	
}
