package day4Pracc;

public interface 점원 {
	void 인사하기();
	void 진열하기();
	void 판매하기();
	
}
