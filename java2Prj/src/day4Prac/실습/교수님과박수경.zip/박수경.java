package day4Pracc;

public class 박수경 implements 점원{

	@Override
	public void 인사하기() {
		System.out.println("어서오세욥~");
		
	}

	@Override
	public void 진열하기() {
		System.out.println("책 가시고기를 진열하는 중..");
		
	}

	@Override
	public void 판매하기() {
		System.out.println("가시고기는 17,000원입니다.");
		
	}
 
}
