package day3.임형택실습;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Stream;

public class CustomerMain {

	public static void main(String[] args) {
		
		ArrayList<Customer> list = new ArrayList<>();
		list.add(new Customer("1", "임형택", "vvip", 5000 ));
		list.add(new Customer("2", "윤현기", "bronze", 4500 ));
		list.add(new Customer("3", "이수민", "silver", 500 ));
		list.add(new Customer("4", "박수경", "gold", 200 ));
		list.add(new Customer("5", "황예지", "vip", 4000 ));
		list.add(new Customer("6", "박하은", "diamond", 3000 ));
		list.add(new Customer("7", "이동우", "vvip", 600 ));
		list.add(new Customer("8", "최지태", "vip", 1000 ));
		list.add(new Customer("9", "김보성", "vvip", 1500 ));
		list.add(new Customer("10", "박시우", "vip", 2500 ));
		
		Stream<Customer> stream = list.stream();
		
		// 고객 등급 vvip 몇명인지 구하기
		long vvip = stream.filter(item -> item.getGrade().equals("vvip")).count();
		System.out.println("vvip인 사람은 :" + vvip + "명 입니다");
		
		// 고객등급이 vip인 사람 출력
		System.out.println("vip인 사람 명단");
		stream = list.stream();
		
		stream.filter(item -> item.getGrade().equals("vip")).forEach( item -> System.out.print(item.getName()+ ", "));
		System.out.println(" ");
		// 포인트가 높은 사람순으로 정렬해서 출력
		System.out.println("포인트 내림차순 정렬");
		stream = list.stream();
		stream.sorted( ( o1, o2) -> o2.getPoint() - o1.getPoint() ).forEach(item -> System.out.println(item));; 
		
		
		
	}

}
