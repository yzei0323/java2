package day3.임형택실습;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.stream.Stream;

public class Stream실습 {

	public static void main(String[] args) {
		
		String[] arr= {"김치","김장","김해","김구"};
		
		Arrays.stream(arr).filter(item -> item.startsWith("김"))
		.forEach(item -> System.out.println(item));
		
		
		ArrayList<String> list = new ArrayList<>();
		list.add("바나나");
		list.add("사과");
		list.add("오렌지");
		list.add("포도");
		list.add("수박");
		
		Stream<String> stream = list.stream();
		stream.forEach(item -> System.out.println(item));
		
		Random r = new Random();
		
		int sum = r.ints(15, 1, 50).distinct().filter(n -> n % 2 == 0).sum();
		
		System.out.println("짝수의 합 :" + sum);
		
		
	}

}
