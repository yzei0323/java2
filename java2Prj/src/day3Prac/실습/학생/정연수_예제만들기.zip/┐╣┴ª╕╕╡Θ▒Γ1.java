package day3Prac.예제만들기;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoublePredicate;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntPredicate;
import java.util.function.IntSupplier;
import java.util.function.LongConsumer;
import java.util.function.LongFunction;
import java.util.function.LongPredicate;
import java.util.function.LongSupplier;
public class 예제만들기1 {

	public static void main(String[] args) {
		
		Runnable r = () -> {
			System.out.println("Runnable 구현");
		};
		r.run();
		
		
		Consumer<String> c = (s) -> {
			System.out.println(s);
        
		};
		c.accept("Consumer 구현");
		
		
		Supplier<String> sup = () -> {return "Supplier 구현";};
		String s = sup.get();
		System.out.println(s);
		
		
		Function<String , String> fun = (ss) -> {
			return ss + " Function 구현";
		};
		String result = fun.apply("Function 구현");
		System.out.println(result);
		
		
		IntFunction<String> inf = (i) -> {
			return i + " IntFunction 구현";
			
		};
		String result2 = inf.apply(100);
		System.out.println(result2);
		
		
		LongFunction<String> lf = (l) -> {
			return l + " LongFunction 구현";
		};
		String result3 = lf.apply(100L);
		System.out.println(result3);
		
		
		DoubleFunction<String> df = (d) -> {
			return d + " DoubleFunction 구현";
		};
		String result4 = df.apply(100.0);
		System.out.println(result4);
		
		
		IntPredicate ip = (i) -> {
			if(i>10) {
				return true;
			}
			else {
				return false;
			}
			
			
		};
		boolean result5 = ip.test(20);
		System.out.println(result5);
		boolean result6 = ip.test(5);
		System.out.println(result6);
		
		
		LongPredicate lp = (l) -> {
			if(l>10) {
				return true;
            }
            else {
                return false;
            }
			
		};
		
		boolean result7 = lp.test(20L);
		System.out.println(result7);
		boolean result8 = lp.test(5L);
		System.out.println(result8);
		
		
		DoublePredicate dp = (d) -> {
			if(d>10) {
				return true;
            }
            else {
                return false;
            }
			
		};
		boolean result9 = dp.test(20.0);
		System.out.println(result9);
		boolean result10 = dp.test(5.0);
		System.out.println(result10);
		
		
		IntConsumer ic = (i) -> {
			System.out.println(i + "int만 받음");
		};
		
		ic.accept(100);
		
		
		LongConsumer lc = (l) -> {
			System.out.println(l + "long만 받음");
        };
		lc.accept(100L);
		
		
		DoubleConsumer dc = (d) -> {
			System.out.println(d + "double만 받음");
		};
		dc.accept(100.0);
		
		
		IntSupplier is = () -> {
			return 100;
		};
		
		int result11 = is.getAsInt();
		System.out.println(result11 + "int형만 뱉음");
		
		
		LongSupplier ls = () -> {
			return 100L;
		};
		long result12 = ls.getAsLong();
		System.out.println(result12 + "long형만 뱉음");
		
		
		DoubleSupplier ds = () -> {
			return 100.0;
		};
		double result13 = ds.getAsDouble();
		System.out.println(result13 + "double형만 뱉음");
		
		
		BiConsumer<String, String> bc = (s1, s2) -> {
			System.out.println(s1 + s2);
		};
		
		bc.accept("BiConsumer 구현", "매개변수 2개 받는 Consumer");
		
		
		BiPredicate bp = (s1, s2) -> {
			if(s1.equals(s2)) {
                return true;
            }
            else {
                return false;
            }
        
		};
		boolean result14 = bp.test("test", "test");
		System.out.println(result14);
		boolean result15 = bp.test("test", "test1");
		System.out.println(result15);
		
		BiFunction<Integer,Integer, String> bf = (s1, s2) -> {
			return s1 + s2 + " BiFunction 구현";
		};
		
		String result16 = bf.apply(100, 200);
		System.out.println(result16);
		
		
		BinaryOperator<Integer> bo = (s1,s2) -> {
			return s1 + s2;
        
		};
		int result17 = bo.apply(100, 200);
		System.out.println(result17);
		
		
	}
}
