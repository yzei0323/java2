package day3Prac.예제만들기;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.function.Consumer;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Stream예제만들기 {

	public static void main(String[] args) {
		// 스트림 연습1
		String[] str = { "사과", "바나나", "망고", "딸기", "체리" };
		Arrays.stream(str);
		
		for (String item : str) {
            System.out.println(item);
        }
		
		ArrayList<String> list = new ArrayList<>();
		list.add("사과");
		list.add("바나나");
		list.add("망고");
		list.add("딸기");
		list.add("체리");
		
		Collections.sort(list);
		for (String item : list) {
			System.out.println(item);
		}
		
		// 스트림 문제: 정렬된 리스트에서 짝수만 출력하기
		Random random = new Random();
		
		ArrayList<Integer> numbers = new ArrayList<>();
		int[] nums = new int[10];
//		int number = random.nextInt(100);
//		for(int i=0; i < 10; i++) {
//			numbers.add(random.nextInt(100));
//		}
		
		for (int i = 0; i < nums.length; i++) {
            nums[i] = random.nextInt(100);
        }
		
		
		System.out.println("정렬 전: " + numbers);
		// 정렬 후 짝수의 합 구하기
		IntStream stream = Arrays.stream(nums);
		IntStream stream2 = new Random().ints(1, 100).limit(10);
		int result = stream2.filter(n -> n % 2 == 0).sum();
		System.out.println("짝수의 합: " + result);
		int result2 = stream.filter(n -> n % 2 == 0).sum();
		System.out.println("짝수의 합: " + result2);
		//stream.filter(n -> n % 2 == 0).sum();
		int sum = 0;
		for (int i = 0; i < numbers.size(); i++) {
			
			if (numbers.get(i) % 2 == 0) {
				sum += numbers.get(i);
			}
			
		}
	
		
		
		ArrayList<Customer> lists = new ArrayList<>();
		lists.add(new Customer("a001", "홍길동", "vip", 1000));
		lists.add(new Customer("a002", "김길동", "vvip", 2000));
		lists.add(new Customer("a003", "개길동", "bronze", 500));
		lists.add(new Customer("a004", "이길동", "vip", 1500));
		lists.add(new Customer("a005", "박길동", "vvip", 3000));
		lists.add(new Customer("a006", "최길동", "bronze", 700));
		lists.add(new Customer("a007", "정길동", "vip", 1200));
		lists.add(new Customer("a008", "오길동", "vvip", 2500));
		lists.add(new Customer("a009", "임길동", "bronze", 600));
		
		Stream<Customer> customerStream = lists.stream();
		//customerStream.filter(c -> c.getGrade().equals("vvip")).forEach(c -> System.out.println(c));
		//customerStream.filter(c -> c.getGrade().equals("vip")).forEach(c -> System.out.println(c));
		//customerStream.sorted((c1,c2) -> c2.getPoint() - c1.getPoint()).forEach(c -> System.out.println(c));
		
		
		
	    
		
		
		
	}
}
