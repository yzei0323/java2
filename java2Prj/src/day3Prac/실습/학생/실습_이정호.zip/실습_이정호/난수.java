package day3Prac.실습;

import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

public class 난수 {

	public static void main(String[] args) {
		IntStream stream = new Random().ints(1, 100).distinct().limit(10);
		int[] numbers = stream.toArray();

		int evenTot = Arrays.stream(numbers).filter(n -> n%2 == 0).sum();
		System.out.println(evenTot);
	}

}
