package day3Prac.실습;

import java.util.ArrayList;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		ArrayList<Customer> list = new ArrayList<>();
		
		list.add(new Customer("user1", "KIM", "vvip", 100));
		list.add(new Customer("user2", "LEE", "vip", 200));
		list.add(new Customer("user3", "PARK", "bronze", 300));
		list.add(new Customer("user4", "CHOI", "vvip", 400));
		list.add(new Customer("user5", "JO", "vip", 500));
		list.add(new Customer("user6", "KANG", "bronze", 600));
		list.add(new Customer("user7", "JEON", "vvip", 700));
		list.add(new Customer("user8", "HWANG", "vip", 800));
		list.add(new Customer("user9", "YOON", "bronze", 800));
		list.add(new Customer("user10", "SON", "vvip", 1000));
		
		Stream<Customer> stream = list.stream();
		
		System.out.print("고객등급이 vvip인 사람 수 : ");
		long count = stream.filter(item -> item.getGrade() == "vvip").count();
		System.out.println(count + "명");
		System.out.println();
		
		System.out.println("<고객등급이 vip사람만 출력>");
		stream = list.stream();
		stream.filter(item -> item.getGrade() == "vip").forEach(item -> System.out.println(item));
		System.out.println();
		
		System.out.println("<포인트가 높은 사람순으로 정렬>");
		stream = list.stream();
		stream.sorted((o1, o2) -> o2.getPoint() - o1.getPoint()).forEach(item -> System.out.println(item));
	}

}
