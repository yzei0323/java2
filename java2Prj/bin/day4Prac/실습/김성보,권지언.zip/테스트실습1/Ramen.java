package day4Prac.테스트실습1;

public class Ramen implements Cooking{

	@Override
	public void cook(int num) {
		System.out.println("라면 만들기 성공");
	}

}
