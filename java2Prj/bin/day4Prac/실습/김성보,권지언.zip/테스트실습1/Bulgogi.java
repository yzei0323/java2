package day4Prac.테스트실습1;

public class Bulgogi implements Cooking{

	@Override
	public void cook(int num) {
		System.out.println("불고기 만들기 성공");
	}

}
