package day4Prac.테스트실습1;

public class Kimbab implements Cooking{

	@Override
	public void cook(int num) {
		System.out.println("김밥 만들기 성공");
	}

}
