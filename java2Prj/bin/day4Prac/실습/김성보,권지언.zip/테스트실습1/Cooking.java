package day4Prac.테스트실습1;

public interface Cooking {

	void cook(int num);
	
}
