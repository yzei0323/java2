package day4Prac.여행일수계산;

public interface Transportation {
	int travel_period(int howlong);
}
