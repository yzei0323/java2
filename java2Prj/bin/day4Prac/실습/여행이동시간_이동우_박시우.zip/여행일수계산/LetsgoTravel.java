package day4Prac.여행일수계산;

public class LetsgoTravel {
	public static void main(String[] args) throws Exception {
		Main2 m = new Main2();
		m.setTransportation(m.ready());
		m.run();
	}
}
