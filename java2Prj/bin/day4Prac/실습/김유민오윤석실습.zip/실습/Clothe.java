package day4.prac.실습;

public interface Clothe {
	
	String wear(String hat, String top, String bottom);
}
