package day4.prac.실습;

public interface Job {
	
     String use(String skillName1, String skillName2);
}
