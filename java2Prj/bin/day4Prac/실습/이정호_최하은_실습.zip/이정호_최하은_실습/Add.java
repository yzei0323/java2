package day4Prac.실습2인;

public class Add implements Calculator {
	@Override
	public int cal(int num1, int num2) {
		return num1 + num2;
	}
}
