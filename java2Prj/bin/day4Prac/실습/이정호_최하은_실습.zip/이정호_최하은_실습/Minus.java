package day4Prac.실습2인;

public class Minus implements Calculator {
	@Override
	public int cal(int num1, int num2) {
		return num1 - num2;
	}
}
