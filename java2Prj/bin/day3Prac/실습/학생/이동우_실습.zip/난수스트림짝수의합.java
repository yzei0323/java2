package day3.prac.my;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.IntStream;

public class 난수스트림짝수의합 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Set<Integer> nanSu  =new HashSet<>();
		
		Random r = new Random();
		
		for(int i = 0; i < 100; i++) {
			nanSu.add(r.nextInt(100));
		}
		
//		System.out.println(nanSu.size());
		
		Integer[] result = new Integer[10];
		Object[] su = nanSu.toArray();
		
		// 10개의 수를 result 배열에 넣기
		System.arraycopy(su, 0, result, 0, 10);
		
		// 랜덤 난수 출력
//		System.out.println(Arrays.toString(result));
		
		// 짝수만 출력하기
		Arrays.stream(result).filter(n -> n%2 == 0).forEach(item -> System.out.print(item + ", "));
		
		

		
		
		// 방법 2)
		System.out.println("\n=========================");
		IntStream stream = new Random().ints(1,100);
		//1~100까지 10개의 랜덤수 나타내기
		
		
		int total = stream.distinct().limit(10).sorted().filter(n -> n%2==0).sum();
		
		System.out.println(total);
		
		
		
	}

}
